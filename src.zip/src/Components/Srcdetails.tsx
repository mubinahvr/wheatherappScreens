import { View, Text,Image,Pressable, StyleSheet,FlatList, TouchableOpacity } from 'react-native'
import React from 'react'

const Srcdetails = ({navigation}) => {
    const DATA = [
        {
            time: "12Am",
            temp: 23.8,

        },
        {
            time: "1Am",
            temp: 23.8
        },
        {
            time: "2Am",
            temp: 22.8
        },
        {
            time: "3Am",
            temp: 23.8
        },
        {
            time: "4Am",
            temp: 22.8
        },
        {
            time: "5Am",
            temp: 23.8
        },
        {
            time: "6Am",
            temp: 23.8
        },
        
    ]
    const Data3=[
        {
            data:"Saturday",
            Image:require("../Images/sun.png"),
            temp:84.2,
            dec:77.2,
            inc:78.2
        },
        {
            data: "Sunday",
            Image: require("../Images/cloudsandsun.png"),
            temp: 84.2,
            dec: 77.2,
            inc: 78.2
        },
        {
            data: "Monday",
            Image: require("../Images/cloud.png"),
            temp: 84.2,
            dec: 77.2,
            inc: 78.2
        }
    ]
    const Data2 = [
        {
            data: 'Sunrise',
            values: '05:00AM',
            id: 1
        },
        {
            data: "wind",
            values: "13km/h",
            id: 2

        },
        {
            data: "Precipitation",
            values: '0mm',
            id: 3
        },
        {
            data: 'Sunset',
            values: '06:43PM',
            id: 4
        },
        {
            data: "Pressure",
            values: "1016mb",
            id: 5

        },
        {
            data: "Humidity",
            values: '70%',
            id: 6
        }
    ]
  return (
      <View style={styles.mainDiv}>
          
          <Text style={styles.div2txt}>Bangalore</Text>
          <Text style={styles.div2txt2}>India</Text>
          <View>
              <FlatList
                  horizontal
                  data={DATA}

                  renderItem={({ item }) =>

                      <View style={{ borderBottomWidth: 1, borderColor: '#ccc', paddingBottom: 10, paddingTop: 10,borderTopWidth:1,marginTop:20, }}>
                          <Text style={styles.flatliststle}>{item.time}</Text>
                          <Text style={styles.flatliststle6}>{item.temp}&deg;</Text>
                      </View>
                  }

              />
          </View>
          <View>
              <FlatList
               
                  data={Data3}

                  renderItem={({ item }) =>

                      <View style={{display:'flex',flexDirection:'row',justifyContent:'space-between'}}>
                          <Text style={styles.flatliststle}>{item.data}</Text>
                          <Image style={styles.flatliststle2} source={item.Image}/>
                          <Text style={styles.flatliststle}>{item.temp}&deg;</Text>
                          <Text style={styles.flatliststle}>{item.dec}&deg;</Text>
                          <Text style={styles.flatliststle}>{item.inc}&deg;</Text>
                      </View>
                  }

              />
          </View>
          <View style={{ borderColor: '#ccc', paddingBottom: 10, paddingTop: 10, borderTopWidth: 1, marginTop: 20 }}>
              <FlatList

                  data={Data2}
                  numColumns={3}
                  renderItem={({ item }) =>

                      <View >
                          <Text style={styles.flatliststle3}>{item.data}</Text>
                          <Text style={styles.flatliststle4}>{item.values}</Text>
                      </View>
                  }

              />
              

          </View>
    </View>
  )
}
const styles=StyleSheet.create({
    mainDiv: {
        padding: 5,
        backgroundColor: '#37C0F7',
        height: '100%'
    },
    div2txt: {
        
        textAlign: 'center',
        color: 'white',
        fontSize:30
    },
    div2txt2: {
       marginTop: 10,
        textAlign: 'center',
        color: '#cEE',
       fontSize: 20
    },
    flatliststle: {
        color: '#eee',
        margin: 10,
        fontSize: 15,
    },
    flatliststle6:{
        color: 'white',
        margin: 10,
        marginTop:5,
        fontSize: 20,
    },
    flatliststle2: {
        color: 'white',
       width:30,
       height:30,
        margin: 10,

    },
    flatliststle3: {
        color: '#ccc',
        margin: 10,
        fontSize: 18,
        marginTop:20,
    },
    flatliststle4: {
        color: 'white',
        fontSize: 22,
        margin: 10,

    }
})
export default Srcdetails