import { View, Text, TextInput, Button, Image, FlatList, Pressable, TouchableOpacity, Modal } from 'react-native'
import React, { useState } from 'react'
import { StyleSheet } from 'react-native'
import Srcdetails from './Srcdetails'

const SearchCity = ({ navigation }) => {
    const [modalVisible, setmodalVisible] = useState(false)
    const DATA = [
        {
            time: "12Am",
            temp: 23.8,

        },
        {
            time: "1Am",
            temp: 23.8
        },
        {
            time: "2Am",
            temp: 22.8
        },
        {
            time: "3Am",
            temp: 23.8
        },
        {
            time: "4Am",
            temp: 22.8
        },
        {
            time: "5Am",
            temp: 23.8
        },
        {
            time: "6Am",
            temp: 23.8
        },
    ]
    const Data2 = [
        {
            data: 'Sunrise',
            values: '05:00AM',
            id: 1
        },
        {
            data: "wind",
            values: "13km/h",
            id: 2

        },
        {
            data: "Precipitation",
            values: '0mm',
            id: 3
        },
        {
            data: 'Sunset',
            values: '06:43PM',
            id: 4
        },
        {
            data: "Pressure",
            values: "1016mb",
            id: 5

        },
        {
            data: "Humidity",
            values: '70%',
            id: 6
        }
    ]
    return (
        <>
        <View style={styles.mainDiv}>
            <View style={styles.div1}>
                <TextInput
                    placeholder='Search City'
                    style={styles.txtinput}
                    placeholderTextColor="#fff" />

                <Text style={styles.btnclr}>&deg;C</Text>
                {/* <Text> {entities.decode(arabic)} </Text> */}
            </View>
            <View style={styles.div2}>
                <Text style={styles.div2txt}>Saturday June 3</Text>
                <Text style={styles.div2txt2}>Bangalore</Text>
                <Text style={styles.div2txt}>India</Text>
            </View>
            <View style={styles.div3}>
                <View style={{ display: 'flex', flexDirection: 'column' }}>
                    <Text style={styles.div3txt}>29&deg;</Text>
                    <Text style={{ paddingLeft: 30, color: '#ccc', fontSize: 15 }}>Feels like 29.9&deg;</Text>

                    <Text style={{ paddingLeft: 20, color: '#fff', fontSize: 20 }}>&#8964;22.6&deg;&nbsp;&nbsp;&nbsp;&#8963;36.8&deg;</Text>
                </View>
                <Image source={require('../Images/cloudsandsun.png')} style={styles.div3img}></Image>
            </View>
            <View style={styles.div4}>
                <Text style={styles.div4txt1}>Partly cloudy</Text>
            </View>
            <View>
                <FlatList
                    horizontal
                    data={DATA}

                    renderItem={({ item }) => <View style={{ borderBottomWidth: 1, borderColor: '#ccc', paddingBottom: 10, paddingTop: 10 }}>
                        <Text style={styles.flatliststle}>{item.time}</Text>
                        <Text style={styles.flatliststle2}>{item.temp}&deg;</Text>
                    </View>} />
            </View>
            <View>
                <FlatList

                    data={Data2}
                    numColumns={3}
                    renderItem={({ item }) => <View>
                        <Text style={styles.flatliststle}>{item.data}</Text>
                        <Text style={styles.flatliststle2}>{item.values}</Text>
                    </View>} />
                <TouchableOpacity onPress={() => {
                    setmodalVisible(true)
                } }>
                    <Image source={require('../Images/up-arrows.png')}
                      
                      style={{ height: 20, width: 20, alignSelf: 'center',
                      justifyContent:'flex-end',tintColor:'white' }} />
                </TouchableOpacity>

            </View>
            <View>

            </View>

        </View><Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible}
        >
                <View
                    style={{
                      margin:0
                    }}>
                    <TouchableOpacity
                        onPress={() => setmodalVisible(!modalVisible)}
                        style={{ width: '100%', backgroundColor: '#37C0F7' }}>
                        <Image source={require('../Images/arrow.png')}
                            style={{ height: 20, 
                            width: 20, 
                            alignSelf: 'center',
                             margin: 20,
                                tintColor: 'white',
                                backgroundColor:'#37C0F7' }} />
                    </TouchableOpacity>
                    <TouchableOpacity

                        onPress={() => {
                            setmodalVisible(!modalVisible)
                        } }>
                        <Srcdetails navigation={Srcdetails} />

                    </TouchableOpacity>
                </View>
            </Modal></>

    )
}
const styles = StyleSheet.create({
    mainDiv: {
        padding: 10,
        backgroundColor: '#37C0F7',
        height: '100%'
    },
    txtinput: {
        borderWidth: 1,
        borderRadius: 30,
        width: '90%',
        padding: 10,
        paddingLeft: 15,
        backgroundColor: '#83DCFA',
        borderColor: '#83DCFA',
        color: 'white',
        marginTop: 2,
        marginBottom: 10
    },
    div1: {
        display: 'flex',
        flexDirection: 'row'
    },
    div3: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-evenly'
    },
    btnclr: {
        color: 'white',
        alignSelf: 'center',
        padding: 5,
        fontSize: 20
    },
    div2txt: {
        marginTop: 10,
        textAlign: 'center',
        color: 'white'
    },
    div2txt2: {
        textAlign: 'center',
        color: 'white',
        fontSize: 22
    },
    div4txt1: {
        textAlign: 'center',
        color: 'white',
        fontSize: 30,
        padding: 20,
        width: '100%',
        borderBottomWidth: 1,
        borderColor: '#ccc'
    },
    div3txt: {
        marginTop: 10,
        textAlign: 'center',
        color: 'white',
        paddingLeft: 10,
        fontSize: 60
    },
    div3img: {
        width: 100,
        height: 100,

    },
    flatliststle: {
        color: '#ccc',
        margin: 10,
        fontSize: 18,
    },
    flatliststle2: {
        color: 'white',
        fontSize: 22,
        margin: 10,

    }
})
export default SearchCity